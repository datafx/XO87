#include QMK_KEYBOARD_CONFIG_H

#undef TAPPING_TERM
#define TAPPING_TERM 300 //At 500 some bad logic takes hold
#define IGNORE_MOD_TAP_INTERRUPT
