#pragma once

// This is the ideal value for me but find your own
#undef TAPPING_TERM
#define TAPPING_TERM 145 

// more options here: https://docs.qmk.fm/config_options.html
#define FORCE_NKRO
#define PERMISSIVE_HOLD // tab/hold-Keys should work better with that
