# ErgoDox EZ Absenth Configuration

## Changelog


* Sept. 14, 2016 (V0.2):
  * Added Space Cadet to Left and Right Shift.  Pressing Left shift with no other key adds an "(" and pressing Right shift with no other key adds an ")"
* Sept. 8, 2016 (V0.1): 
  * Made A key double as MEDIA Layer change when you hold it.  Added mouse buttons to the large thumb buttons on the left side on the Media Layer.  Added vi/vim style arrow keys on HJKL on media layer.

![Absenth](https://i.imgur.com/D1enl2x.jpg)
