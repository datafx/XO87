# 68_ansi

    LAYOUT_68_ansi

This is the 68 key ANSI layout made popular by boards such as the Magicforce 68 and Varmilo VA68M. 