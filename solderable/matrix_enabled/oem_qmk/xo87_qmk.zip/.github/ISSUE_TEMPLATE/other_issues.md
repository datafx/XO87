---
name: Other issues
about: Anything else that doesn't fall into the above categories.
title: ''
labels: help wanted, question
assignees: ''

---

<!--- Provide a general summary of the changes you want in the title above. -->

<!--- Anything on lines wrapped in comments like these will not show up in the final text. -->

<!-- Please check https://docs.qmk.fm/#/support for additional resources first. If that doesn't answer your question, choose the bug report template instead, as that may be more appropriate. -->
