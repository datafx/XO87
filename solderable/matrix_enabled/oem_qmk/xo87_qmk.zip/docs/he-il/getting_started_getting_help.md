<div dir="rtl" markdown="1">
# קבלת עזרה

ישנם משאבים רבים לצורך קבלת עזרה עם QMK.

## צ׳אט בזמן אמת

אפשר למצוא מפתחי QMK ומשתמשים [בשרת ה-Discord הראשי שלנו](https://discord.gg/Uq7gcHh). ישנם ערוצים ספציפיים בשרת לצורך שיחות על הקושחה, ארגז הכלים, חומרה והמגדיר.

## סאב-רדיט OLKB

הפורום הרשמי של QMK נמצא ב - [/r/olkb](https://reddit.com/r/olkb) באתר [reddit.com](https://reddit.com).

## סוגיות GitHub

ניתן לפתוח [סוגייה ב-GitHub](https://github.com/qmk/qmk_firmware/issues). הדבר שימושי במיוחד כאשר הסוגיה דורשת דיון עמוק וארוך או דיבאגינג.
</div>