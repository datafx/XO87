# The default keymap for rgb

**RGB PCB (AVAILABILITY: CHINA + INTERNATIONAL GB)**
The "rgb" directory includes the keymap for the RGB PCB.

The multi-layout PCB and RGB pcb were the only two options available to NON-china buyers.
If you purchased a non-rgb PCB, please see the 'multi' directory.