/* Copyright 2019 MechMerlin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "rgb.h"
#include "rgb_matrix_types.h"
#include <print.h>
#include "raw_hid.h"
#include "usb_descriptor.h"
#include "rgb_matrix.h"



#define noLed {255,255}

#define ledSollSP (80+3)
#define ledNumSP (80+7)
#define ledCapSP (80+8)


u8 led_backLight_val;

extern backlight_config_t backlight_config;
led_t led_s;

static u16 minAdress=0xfe80;//最小64k-4k
static u16 maxAdress=0xfea0;//最大64k


u8 rgbSp,r,g,b;
typedef struct
{

u8 step;
u8 brightnessStep;
u8 pressIndex;
u8 KeyLedBrightness[KEYLED_ROWS*KEYLED_COLS];//对应灯的亮度值
u8 ledonSp;
u8 delayRhythmOut;
}keyLedDrive_;

keyLedDrive_ keyLedDrive;

RhythmLed_ RhythmLed;
backLedRgbG_ backLedRgbG;
u16 RhythmLed_timeOutR0;//超时退出律动

static pin_t key_led_row_pins[KEYLED_ROWS] = KEYLED_ROW_PINS;
static pin_t key_led_col_pins[KEYLED_COLS] = KEYLED_COL_PINS;


void ledSollSet(bool onf)
{
    if(onf)
    {
        keyLedDrive.KeyLedBrightness[ledSollSP]=brightnessMax;

    }
    else
    {

     keyLedDrive.KeyLedBrightness[ledSollSP]=0;

    }
}


void ledNumSet(bool onf)
{
     if(onf)
    {
        keyLedDrive.KeyLedBrightness[ledNumSP]=brightnessMax;

    }
    else
    {

     keyLedDrive.KeyLedBrightness[ledNumSP]=0;

    }

}

void ledCapsSet(bool onf)
{
    if(onf)
    {
        keyLedDrive.KeyLedBrightness[ledCapSP]=brightnessMax;

    }
    else
    {

     keyLedDrive.KeyLedBrightness[ledCapSP]=0;

    }
}

extern rgblight_config_t rgblight_config;

void updateBackLight(void)
{
u8 i;
u8 level=backlight_config.level;
    reflashLedState();

    if(level>brightnessMax)
        level=brightnessMax;

    if(level!=led_backLight_val)
    {
        for(i=0;i<(KEYLED_ROWS*KEYLED_COLS);i++)
        {
            if((i==ledNumSP)||(i==ledCapSP)||(i==ledSollSP))
            {

            }
            else
                keyLedDrive.KeyLedBrightness[i]=level;
        }
    }
    led_backLight_val=level;
}

extern uint8_t getLightLevel(void)
{
    return backlight_config.level;
}

void updateRgbBackLight(void)
{
    u8 i=0;
    if(rgblight_get_mode()!=1)
    {
        rgblight_mode(1);
    }
    for(i=0;i<colorAGSize;i++)
    {
        rgblight_buf_setrgb_at(backLedRgbG.colorAG[i].r,backLedRgbG.colorAG[i].g,backLedRgbG.colorAG[i].b,i);


    }
    for(i=0;i<(colorBGSize);i++)
    {
        rgblight_buf_setrgb_at(backLedRgbG.colorBG[i].r,backLedRgbG.colorBG[i].g,backLedRgbG.colorBG[i].b,i+colorAGSize);
    }
   rgblight_set();

}

void raw_hid_receive(uint8_t *data, uint8_t length) {


}


bool checkKey(void)
{

}

void matrix_init_kb(void) {
  // put your keyboard start-up code here
  // runs once when the firmware starts up
 // CONSOLE_ENABLE = yes;
    u8 i;
	debug_enable = true;
    rgbSp=0;

    for(i=0;i<KEYLED_ROWS;i++)
    {
        setPinOutput(key_led_row_pins[i]);
        writePinLow(key_led_row_pins[i]);
    }
    for(i=0;i<KEYLED_COLS;i++)
    {
        setPinOutput(key_led_col_pins[i]);
        writePinLow(key_led_col_pins[i]);
    }
    for(i=0;i<(KEYLED_ROWS*KEYLED_COLS);i++)
    {
        keyLedDrive.KeyLedBrightness[i]=1;//i%brightnessMax+1;
    }

	debug_matrix = true;
	debug_mouse  = true;
  setPinInput(E6);
  matrix_init_user();


}
void setKeyLedBrightness(u8 x,u8 y,u8 Brightness)
{
    u8 i;
    i=0;
    keyLedDrive.KeyLedBrightness[i]=Brightness;
}
void KeyLedCom(void)
{
    writePinLow(key_led_row_pins[keyLedDrive.step]);
}

void LampEffectFadeAway2Zero(u8 deci)
{
u8 i;
    for(i=0;i<(KEYLED_ROWS*KEYLED_COLS);i++)
    {
        if(keyLedDrive.KeyLedBrightness[i]>0)
        {
            keyLedDrive.KeyLedBrightness[i]--;
        }
    }

}


void reflashLedState(void)
{
    ledCapsSet(led_s.caps_lock);
    ledNumSet(led_s.num_lock);
    ledSollSet(led_s.scroll_lock);
}
bool led_update_user(led_t led_state) {

    led_s=led_state;

  return true;
}
u8 deltr0;
void keyLedDriver(void)
{
u8 i;
u8 sp;
u16 li;
u8 stepT;

     cli();
    for(i=0;i<KEYLED_COLS;i++)
    {
        sp=keyLedDrive.step*KEYLED_COLS+i;
        if(keyLedDrive.KeyLedBrightness[sp]>keyLedDrive.brightnessStep)
            writePinHigh(key_led_col_pins[i]);
        else
        {
           writePinLow(key_led_col_pins[i]);

        }

    }
    for(li=0;li<10;li++)
        writePinHigh(key_led_row_pins[keyLedDrive.step]);
    updateBackLight();

    stepT=keyLedDrive.step;

    keyLedDrive.step++;
    if(keyLedDrive.step>=KEYLED_ROWS)
    {
        keyLedDrive.step=0;
        keyLedDrive.brightnessStep++;
        if(keyLedDrive.brightnessStep>=brightnessMax)
        {
            keyLedDrive.brightnessStep=0;

        }
    }
    writePinLow(key_led_row_pins[stepT]);


    sei();

}
void matrix_scan_user(void) {

}
void matrix_scan_kb(void) {
  // put your looping keyboard code here
  // runs every cycle (a lot)
   matrix_scan_user();
}

bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
  // put your per-action keyboard code here
  // runs for every action, just before processing by the firmware

  return process_record_user(keycode, record);
}


